package com.example.demo;

import com.example.demo.model.Bus;
import com.example.demo.Service.BusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/buses")
public class BusController {
    @Autowired
    private BusService busService;

    @GetMapping("/search")
    public ResponseEntity<List<Bus>> searchBuses(
        @RequestParam String departureLocation,
        @RequestParam String arrivalLocation,
        @RequestParam String departureTime) {
        return ResponseEntity.ok(busService.searchBuses(departureLocation, arrivalLocation, departureTime));
    }
}
