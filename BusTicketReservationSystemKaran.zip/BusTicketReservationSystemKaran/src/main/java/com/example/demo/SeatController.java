package com.example.demo;

import com.example.demo.model.Seat;
import com.example.demo.Service.SeatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/seats")
public class SeatController {
    @Autowired
    private SeatService seatService;

    @GetMapping("/available/{busId}")
    public ResponseEntity<List<Seat>> getAvailableSeats(@PathVariable Long busId) {
        return ResponseEntity.ok(seatService.findAvailableSeats(busId));
    }

    @PostMapping("/reserve/{seatId}")
    public ResponseEntity<Seat> reserveSeat(@PathVariable Long seatId) {
        return ResponseEntity.ok(seatService.reserveSeat(seatId));
    }
}
