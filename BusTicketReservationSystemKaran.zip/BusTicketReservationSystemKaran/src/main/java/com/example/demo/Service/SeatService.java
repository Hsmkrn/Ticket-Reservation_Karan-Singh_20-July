package com.example.demo.Service;

import com.example.demo.model.Seat;
import com.example.demo.repository.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeatService {
    @Autowired
    private SeatRepository seatRepository;

    public List<Seat> findAvailableSeats(Long busId) {
        return seatRepository.findByBusIdAndReserved(busId, false);
    }

    public Seat reserveSeat(Long seatId) {
        Seat seat = seatRepository.findById(seatId).orElseThrow(() -> new IllegalArgumentException("Invalid seat Id:" + seatId));
        seat.setReserved(true);
        return seatRepository.save(seat);
    }
}
