package com.example.demo.Service;

import com.example.demo.model.Bus;
import com.example.demo.repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusService {
    @Autowired
    private BusRepository busRepository;

    public List<Bus> searchBuses(String departureLocation, String arrivalLocation, String departureTime) {
        return busRepository.findByDepartureLocationAndArrivalLocationAndDepartureTime(departureLocation, arrivalLocation, departureTime);
    }
}
