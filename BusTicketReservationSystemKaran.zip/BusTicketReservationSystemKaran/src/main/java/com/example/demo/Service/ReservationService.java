package com.example.demo.Service;

import com.example.demo.model.Reservation;
import com.example.demo.model.Customer;
import com.example.demo.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class ReservationService {
    @Autowired
    private ReservationRepository reservationRepository;

    public Reservation makeReservation(Customer user, Long seatId) {
        Reservation reservation = new Reservation();
        reservation.setUser(user);
        reservation.setId(seatId); //updated
        reservation.setReservationDate(new Date());
        return reservationRepository.save(reservation);
    }

    public List<Reservation> findByUserId(Long userId) {
        return reservationRepository.findByUserId(userId);
    }
}
