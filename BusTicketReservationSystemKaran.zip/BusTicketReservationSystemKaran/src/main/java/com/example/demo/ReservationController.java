package com.example.demo;


import com.example.demo.model.Reservation;
import com.example.demo.model.Customer;
import com.example.demo.Service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reservations")
public class ReservationController {
    @Autowired
    private ReservationService reservationService;

    @PostMapping("/make/{seatId}")
    public ResponseEntity<Reservation> makeReservation(@PathVariable Long seatId) {
        Customer user = (Customer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ResponseEntity.ok(reservationService.makeReservation(user, seatId));
    }

    @GetMapping("/user")
    public ResponseEntity<List<Reservation>> getUserReservations() {
        Customer user = (Customer) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ResponseEntity.ok(reservationService.findByUserId(user.getId()));
    }
}
