package com.example.demo.service;

import com.example.demo.Service.BusService;
import com.example.demo.model.Bus;
import com.example.demo.repository.BusRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class BusServiceTest {

    @InjectMocks
    private BusService busService;

    @Mock
    private BusRepository busRepository;

    public BusServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSearchBuses() {
        Bus bus = new Bus();
        bus.setDepartureLocation("Location A");
        bus.setArrivalLocation("Location B");
        bus.setDepartureTime("10:00");
        bus.setArrivalTime("12:00");
        List<Bus> buses = Collections.singletonList(bus);

        when(busRepository.findByDepartureLocationAndArrivalLocationAndDepartureTime(
                "Location A", "Location B", "10:00")).thenReturn(buses);

        List<Bus> result = busService.searchBuses("Location A", "Location B", "10:00");
        assertEquals(buses, result);
    }
}
